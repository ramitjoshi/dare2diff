Example of JWPlayer - A Flash and HTML 5 player for videos

This example demonstrates how to show youtube videos using jwplayer
