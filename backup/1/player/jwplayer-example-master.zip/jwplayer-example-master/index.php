<html>
<head>
<script type='text/javascript' src='jwplayer/jwplayer.js'></script>
</head>

<body>
<div id='container'>Loading the player...</div>
<script type='text/javascript'>
jwplayer('container').setup({
  flashplayer: 'jwplayer/player.swf',
  file:'http://www.youtube.com/watch?v=bBEUOZ1-_gE',
  height: 400,
  width: 600,
  'playlist.position': 'right',
  'playlist.size': 80
  })

</script>
</body>
</html>
