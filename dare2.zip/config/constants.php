<?php
define("SITE_URL", 'http://localhost/dare2/'); 
define("DB", "dare2");
define("DBUSER", "root");
define("DBPWD", ""); 
define("SALT", "1235786fgg");
define('ROOTPATH', __DIR__);
define('ADMIN_EMAIL','algonquinelectrical@gmail.com'); 
define( 'ABSPATH', dirname(dirname(__FILE__)) . '/' );
?>
