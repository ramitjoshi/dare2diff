<div class="aside-copyright">
	<p><?php echo date('Y'); ?> &copy; Email Stalk Track Company</p>
	<ul>
		<li><a href="#">Privacy</a></li>
		<li><a href="#">Support & FAQ</a></li>
	</ul>
</div>