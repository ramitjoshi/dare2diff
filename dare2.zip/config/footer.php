<div class="script">
       
        <script type="text/javascript" src="<?php echo SITE_URL; ?>assets/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo SITE_URL; ?>assets/js/jquery.validate.js"></script>
        <script type="text/javascript" src="<?php echo SITE_URL; ?>assets/js/form.js"></script>
		<script type="text/javascript" src="<?php echo SITE_URL; ?>assets/js/custom.js"></script>
		<script type="text/javascript" src="<?php echo SITE_URL; ?>assets/js/toastr.js"></script>
        <script type="text/javascript" src="<?php echo SITE_URL; ?>assets/js/wow.js"></script>
        <script type="text/javascript">
            var wow = new WOW({
                boxClass: 'wow',
                animateClass: 'animated',
                offset: 140,
                mobile: true,
                live: true,
                callback: function(box) {},
                scrollContainer: null
            });
            wow.init();

        </script> 
</div>
</body>

</html>