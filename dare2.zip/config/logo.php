<?php
if($asd==1)
{	
?>
<a class="navbar-brand" href="<?php echo SITE_URL; ?>">
	<div class="logo-y"> 
		<img src="<?php echo SITE_URL; ?>assets/images/logo-face.png"> 
	</div>
	<div class="logo-eyes" id="viewport">
		<div id="one"><img src="<?php echo SITE_URL; ?>assets/images/logo-eye.png"></div>
		<div id="two"><img src="<?php echo SITE_URL; ?>assets/images/logo-eye.png"></div>
	</div> 
	<img src="<?php echo SITE_URL; ?>assets/images/logo2.png"> 
</a> 
<?php
}
else if($asd==2)
{ 	 
?>
<a class="navbar-brand" href="<?php echo SITE_URL; ?>">
	<div class="logo-y"> <img src="<?php echo SITE_URL; ?>assets/images/logo-face.png"> </div>
	<div class="logo-eyes" id="viewport">
		<div id="one"><img src="<?php echo SITE_URL; ?>assets/images/logo-eye.png"></div>
		<div id="two"><img src="<?php echo SITE_URL; ?>assets/images/logo-eye.png"></div>
	</div> <img src="<?php echo SITE_URL; ?>assets/images/logo2-white.png"> 
</a> 
<?php
}
?>