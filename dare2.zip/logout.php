<?php
require 'setup.php';
unset($_SESSION['user_id']);
?>
<script>window.location.href='index.php';</script>  