# Equation-Solver
A PHP Class that parses and solves different type of equations
