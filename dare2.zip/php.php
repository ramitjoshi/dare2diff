<?php
phpinfo();
?>