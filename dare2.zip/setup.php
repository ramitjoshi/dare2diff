<?php
error_reporting(E_ALL & ~E_NOTICE);
session_start();
require_once  'config/constants.php';
require_once   'config/functions.php'; 
?> 